Activity: 

This code controls five LEDs by gradually increasing and decreasing their brightness in sequence using PWM. 
It first fades in each LED one by one, then fades them out in reverse order, creating a smooth lighting effect.

Members:

Ivan Gabriel A. Peña
Carlo P. Gerbise
Franco Lemuel A. Garcia
Ranjit Arisgado
Allen Matro
Jose Matro

