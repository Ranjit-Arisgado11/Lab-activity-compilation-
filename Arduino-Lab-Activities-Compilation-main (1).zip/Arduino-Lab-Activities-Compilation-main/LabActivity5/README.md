Activity: 

listens for serial input ('1' or '0') and controls an LED on pin 13 accordingly, allowing remote activation or deactivation.

Members:

Ivan Gabriel A. Peña
Carlo P. Gerbise
Franco Lemuel A. Garcia
Ranjit Arisgado
Allen Matro
Jose Matro

