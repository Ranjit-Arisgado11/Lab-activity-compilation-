Activity: 


This Arduino code reads the state of a button using an internal pull-up resistor and sends "group3_off" when pressed and "group3_on" when released via serial communication. 
A short delay is included to prevent excessive data transmission.

Members:

Ivan Gabriel A. Peña
Carlo P. Gerbise
Franco Lemuel A. Garcia
Ranjit Arisgado
Allen Matro
Jose Matro

