Activity: 

This code monitors brightness using a photoresistor and triggers an LED blinking alert if the brightness exceeds a set threshold. 
The blinking continues until a "stop" command is received via the serial monitor, which turns off the LED.

Members:

Ivan Gabriel A. Peña
Carlo P. Gerbise
Franco Lemuel A. Garcia
Ranjit Arisgado
Allen Matro
Jose Matro

