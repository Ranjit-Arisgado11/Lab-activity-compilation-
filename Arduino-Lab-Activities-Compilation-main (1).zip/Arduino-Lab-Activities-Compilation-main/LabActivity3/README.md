Activity: 

This activity  monitors temperature and brightness using a thermistor and photoresistor to detect potential fire hazards. 
If either sensor exceeds a threshold, an LED flashes as an alert, remaining active for a cooldown period before resetting.

Members:

Ivan Gabriel A. Peña
Carlo P. Gerbise
Franco Lemuel A. Garcia
Ranjit Arisgado
Allen Matro
Jose Matro

