Activity: 

This Arduino code reads the state of a button and sends "1" when pressed and "0" when released via serial communication. 
It uses a short delay to prevent excessive data transmission.

Members:

Ivan Gabriel A. Peña
Carlo P. Gerbise
Franco Lemuel A. Garcia
Ranjit Arisgado
Allen Matro
Jose Matro

